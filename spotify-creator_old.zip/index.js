let axios = require("axios");
let qs = require("qs");
let tanya = require("readline-sync");

const Spotify = (username, password, tgl_lahir, bln_lahir, thn_lahir, email) =>
  new Promise((resolve, reject) => {
    function getRandomInt(max) {
      return Math.floor(Math.random() * Math.floor(max));
    }
    let version_ua_phone = [
      "ASUS_T00F",
      "ASUS_T00J",
      "ASUS_T00Q",
      "ASUS_Z007",
      "ASUS_Z00AD",
      "ASUS_X00HD",
    ];
    let data = qs.stringify({
      iagree: "true",
      birth_day: tgl_lahir,
      birth_month: bln_lahir,
      platform: "Android-ARM",
      creation_point: "client_mobile",
      password: password,
      key: "142b583129b2df829de3656f9eb484e6",
      birth_year: thn_lahir,
      email: email,
      gender: "male",
      app_version: "849800892",
      birth_month: "12",
      password_repeat: password,
      username: username,
    });
    let config = {
      method: "post",
      url: "https://spclient.wg.spotify.com:443/signup/public/v1/account/",
      headers: {
        "User-Agent": `Spotify/8.4.98 Android/25 ('${
          version_ua_phone[getRandomInt(version_ua_phone.length)]
        }')`,
        "Content-Type": "application/x-www-form-urlencoded",
        Connection: "Keep-Alive",
      },
      data: data,
    };

    axios(config)
      .then(function (response) {
        if (response.data.status == 1) {
          let json = {
            status: true,
            message: "berhasil",
            result: {
              country: response.data.country,
              username: username,
              password: password,
              email: email,
              ttl: `${tgl_lahir}-${bln_lahir}-${thn_lahir}`,
            },
          };
          resolve(json);
        } else {
          let json = {
            status: false,
            message: "gagal - coba ganti data",
          };
          resolve(json);
        }
      })
      .catch(function (error) {
        console.log(error);
      });
  });

(async () => {
  let mail = tanya.question("Email? ");
  let uname = tanya.question("Username? ");
  let pass = tanya.question("Password? ");
  console.log(`* = Tanpa Angka 0`);
  let tgl = tanya.question("*Tanggal Lahir? ");
  let bln = tanya.question("*Bulan Lahir? ");
  let tahun = tanya.question("Tahun Lahir (FULL)? ");
  if (mail && uname && pass && tgl && bln && tahun) {
    if (tgl > 31 || bln > 12 || tahun > 2003) {
      console.log(`Tanggal Lahir Kok Gitu?`);
    } else {
      let ekse = await Spotify(uname, pass, tgl, bln, tahun, mail);
      if (ekse.status == true) {
        console.log(`=========[Spotify-Account]=========
    Country : ${ekse.result.country}
    Username : ${ekse.result.username}
    Password : ${ekse.result.password}
    Email : ${ekse.result.email}
    TTL : ${ekse.result.ttl}
============[TheRevolt]============`);
      }
    }
  } else {
    console.log(`Data Tidak Boleh Kosong`);
  }
})();
